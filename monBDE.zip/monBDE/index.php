<!DOCTYPE html>
<html>
	<head>
   	 	<meta charset="utf-8" />
   	 	<title>Mon BDE</title>
    	<link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <?php
        include("./header.php");
        include("./connexion.php");
        
        $sql="SELECT * from events";
        if(!$connexion->query($sql)) echo "Pb d'accès au events";
        else{
            echo "<div id='listEvents'>";
            foreach ($connexion->query($sql) as $row){
                echo "<div class='event'>".
                      "<img src='data:image/jpeg;base64,".base64_encode($row['image'])."'/>".
                      "<div><h2>".$row['name']."</h2>".
                      "<a href='event.php?id=".$row['id']."'>voir details</a>".
                     "</div></div>";
            }
            echo "</div>";
        }
        ?>
    </body>
</html>
