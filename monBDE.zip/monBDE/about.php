<!DOCTYPE html>
<html>
	<head>
   	 	<meta charset="utf-8" />
   	 	<title>Mon BDE - Login</title>
    	<link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <?php
          include("./header.php");
          include("./connexion.php");
        ?>
        <h2>A propos du BDE </h2>
        <p>In non pretium velit. Proin eget hendrerit turpis. Donec id orci blandit, fermentum diam eget, feugiat augue. Pellentesque cursus, metus eu auctor elementum, tortor lectus egestas odio, vitae rutrum odio sapien vitae sapien. Proin luctus nunc sed eleifend placerat. Cras nec orci nec dolor mollis eleifend. Etiam porttitor, quam a dapibus interdum, diam orci mollis purus, non mollis mi urna non sapien. Pellentesque a ultrices nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
    </body>
</html>

