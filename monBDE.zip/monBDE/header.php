<?php
session_start();
?>
<div id="TitleTop">
    <h1>Mon BDE</h1>
</div>
<div id="Menu">
    <a href="index.php">Accueil</a>
    <a href="about.php">A propos</a>
    <?php
    if(!isset($_SESSION['user'])){
        echo "<a href='login.php'>Se connecter</a>";
    }else{
        echo "<a href='logout.php'>Déconnection</a>";
    }
    ?>
</div>