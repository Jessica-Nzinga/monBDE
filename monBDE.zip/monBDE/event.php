<!DOCTYPE html>
<html>
	<head>
   	 	<meta charset="utf-8" />
   	 	<title>Mon BDE - Event</title>
    	<link rel="stylesheet" href="style.css" />
    </head>
    <body>
        <?php
          include("./header.php");
          include("./connexion.php");
        
        $stmt = $connexion->prepare("SELECT * FROM events WHERE id=? LIMIT 1"); 
        $stmt->execute(array($_GET['id'])); 
        $row = $stmt->fetch();

        echo "<div class='event'>".
              "<img src='data:image/jpeg;base64,".base64_encode($row['image'])."'/>".
              "<div>".
                "<h2>".$row['name']."</h2>".
                "<p>".$row['description']."</p>".
              "</div>".
              "</div>";

        if(isset($_SESSION['user'])){
          echo "<form method='POST' action='' style='text-align:center;margin:10px'>";
          echo "<input type='submit' name='participer' value='Participer'/>";
          echo "</form>";
        }

        if(isset($_POST["participer"])){
          try{
            $stmt = $connexion->prepare("INSERT INTO `participation` (`event`, `student`)
                                        VALUES (:event, :student);"); 
            $stmt->execute(array("event"=> $_GET['id'],
                                 "student"=>$_SESSION['user']["id"])); 
          }
          catch(PDOException $e){
              printf("Erreur lors de l'inscription : %s\n", $e->getMessage());
              exit();
          }finally{
              echo "<p style='color:green'>Inscription réussite!</p>";
          }
        }

        echo "<div id='listMedia'>";
        $stmt2 = $connexion->prepare("SELECT * FROM eventmedias WHERE event=?"); 
        $stmt2->execute(array($_GET['id'])); 
        $results = $stmt2->fetchAll();
        foreach($results as $media){
          echo "<img src='data:image/jpeg;base64,".base64_encode($media['content'])."'/>";
        }
        echo "</div>";
        ?>
    </body>
</html>

